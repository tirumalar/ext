/* ========================================
 *
 * Copyright YOUR COMPANY, THE YEAR
 * All Rights Reserved
 * UNPUBLISHED, LICENSED SOFTWARE.
 *
 * CONFIDENTIAL AND PROPRIETARY INFORMATION
 * WHICH IS THE PROPERTY OF your company.
 *
 * ========================================
*/
void MotHome();
uint8 MotMoveRel(int steps);
int MotTask();
int MotGetPos(void);
extern uint8 mot_active;
/* [] END OF FILE */
