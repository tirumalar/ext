/* ========================================
 *
 * Copyright YOUR COMPANY, THE YEAR
 * All Rights Reserved
 * UNPUBLISHED, LICENSED SOFTWARE.
 *
 * CONFIDENTIAL AND PROPRIETARY INFORMATION
 * WHICH IS THE PROPERTY OF your company.
 *
 * ========================================
*/
#include "project.h"
#include "motor.h"
#define IC_ADDR 0x60
#define IC_ADDR2 0x61

#define EN_LED0 1
#define EN_LED1 1
void LedRegWrite(uint8 addr, uint8 reg, uint8 val)
{
    uint8 r;
    r=I2C_LED_I2CMasterSendStart(addr,0);
    if (r!=0)
        return;
    I2C_LED_I2CMasterWriteByte(reg);
    I2C_LED_I2CMasterWriteByte(val);
    I2C_LED_I2CMasterSendStop();
    
}

void LedInitRegs(uint8 addr)
{
    // set all leds to be pwm 
    // and write to MODE 1
       LedRegWrite(addr,0x14,0xaa);
       LedRegWrite(addr,0x15,0xaa);
       LedRegWrite(addr,0x16,0xaa);
       LedRegWrite(addr,0x17,0xaa);
       LedRegWrite(addr, 0,0x0);
 }
void LedSetRGB(uint8 addr,uint8 chan, uint8 r, uint8 g , uint8 b)
{
    //if (addr==IC_ADDR)
    //  return;
    LedRegWrite(addr,2+chan*3+2,r);
    LedRegWrite(addr,2+chan*3+1,g);
    LedRegWrite(addr,2+chan*3,b);
   // CyDelay(100);
}
typedef struct
{
    unsigned char action;
    unsigned char chA;
    unsigned char chB;
    unsigned char r;
    unsigned char g;
    unsigned char b;
    unsigned char mot_pos_lo;
    unsigned char mot_pos_hi;
    unsigned char mot_stat;
    unsigned char fill[20];
    
}SETTINGS;
volatile SETTINGS set;

#define ACTION_LED 1
#define ACTION_MOT_HOME 2
#define ACTION_MOT_ABS 3
#define ACTION_MOT_REL 4
void DoLedUpdate(void)
{
    int x;
    
    for(x=0;x<5;x++)
        {
        if (set.chA&(1<<x)) 
            {
            LedSetRGB(IC_ADDR,x,set.r,set.g,set.b);
             LedSetRGB(IC_ADDR2,x,set.r,set.g,set.b);
            }
        }
 }



int main(void)
{
    int x,q,p;
    CyGlobalIntEnable; /* Enable global interrupts. */
   CyDelay(150);
    /* Place your initialization/startup code here (e.g. MyInst_Start()) */
    I2C_LED_Start();
    EZI2C_CAM_EzI2CSetBuffer1(32, 16, &set.action);
    EZI2C_CAM_Start();
    EZI2C_CAM_EzI2CSetBuffer1(32, 16, &set.action);

   
    STEP_COUNT_Start();
    IDAC_1_Start();
    IDAC_1_SetValue(120);
    Comp_ISENSE_Start();
    
    
    
    PWM_M_Start();

 
    PWM_M_WriteCompare1(0);
    AUD_GAIN1_Write(0);
    AUD_GAIN0_Write(1);
    
//    AUDIO_DAC_Start();
    //I2C_LED_sda_SetDriveMode(I2C_LED_sda_DM_STRONG);
    while (0)
    {
     I2C_LED_sda_Write(0);
     I2C_LED_sda_Write(1);
     I2C_LED_scl_Write(0);
     I2C_LED_scl_Write(1);
    
    }
     if (EN_LED1)    
      LedInitRegs(IC_ADDR2);
    if (EN_LED0)    
        LedInitRegs(IC_ADDR);

    for(x=0;x<5;x++)
    {
        if (EN_LED0)    
         LedSetRGB(IC_ADDR,x,60,60,60);
        if (EN_LED1)    
            LedSetRGB(IC_ADDR2,x,60,60,60);
        CyDelayUs(50000);
        CyDelayUs(50000);
        CyDelayUs(50000);
    }
    for(q=0;q<50;q++)
    {
      //  for(x=0;x<5;x++)
        for(x=0;x<5;x++)
            {
            if (EN_LED0)    
                LedSetRGB(IC_ADDR,x,q,q,q);
            if (EN_LED1)    
                LedSetRGB(IC_ADDR2,x,0,q,0);
            }
         CyDelayUs(10000);
    }
    for(x=0;x<5;x++)
        {
        if (EN_LED0) 
            LedSetRGB(IC_ADDR,x,0,0,0);
        if (EN_LED1) 
            LedSetRGB(IC_ADDR2,x,0,0,0);
        }
        
    while (1)
    {
        if (set.action==ACTION_LED)
           {
            DoLedUpdate();
            set.action=0;
           }
       if (set.action==ACTION_MOT_HOME)
        {
            MotHome();
            set.action=0;
        }
       if (set.action==ACTION_MOT_ABS)
        {
            short move_pos= (set.mot_pos_hi<<8) +set.mot_pos_lo;
            if (MotMoveRel(move_pos-MotGetPos()))
               set.action=0;
            
        }
     MotTask();
    set.mot_stat=mot_active;
    }
 
}

/* [] END OF FILE */
