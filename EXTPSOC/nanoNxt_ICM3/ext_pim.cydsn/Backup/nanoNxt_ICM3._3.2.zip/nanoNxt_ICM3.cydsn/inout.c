/* ========================================
 *
 * Copyright YOUR COMPANY, THE YEAR
 * All Rights Reserved
 * UNPUBLISHED, LICENSED SOFTWARE.
 *
 * CONFIDENTIAL AND PROPRIETARY INFORMATION
 * WHICH IS THE PROPERTY OF your company.
 *
 * ========================================
*/

// GRI 1-13-2015 - Revised for 3.1.1;  TAMPER_OUT must not be set in SetHardwareVals - has been moved to HandleInputs.
// GRI 2-04-2015 - Revised for 3.1.5;  Extensive revision to input signal checker to add debounce/noise immunity.

#include <project.h>
#include "system.h"
#include "i2cuart.h"

//int pwr_cnt;

// this function reads the current settings from the file register 
// and configures the outputs accordingly
void  SetHardwareVals(int val)
{
    // 1 - low ; 0 - high

    if((val&LED_OUT_RED) == LED_OUT_RED) 
	    LEDR_OUT_Write(1);
    else
        LEDR_OUT_Write(0);
        
    if((val&LED_OUT_GRN) == LED_OUT_GRN) 
	    LEDG_OUT_Write(1);
    else
        LEDG_OUT_Write(0);
        
	 if((val&SOUNDER_OUT) == SOUNDER_OUT) 
	    SOUND_OUT_Write(1);
    else
        SOUND_OUT_Write(0);

    // TAMPER_OUT logic is now moved to HandleInputs.  (GRI 1-13-15, 2-3-15)
    // TAMPER_POL is incoming webconfig polarity bit for CR tamper.
    if((val&TAMPERCR_POL) == TAMPERCR_POL)  
        TAMPERCR_POLARITY = 1;
   else
        TAMPERCR_POLARITY = 0;
                
    if((val&RELAY_1_OUT) == RELAY_1_OUT) 
        RELAY_A_Write(1);
    else
        RELAY_A_Write(0);
        
    if((val&RELAY_2_OUT) == RELAY_2_OUT) 
        RELAY_B_Write(1);
    else
        RELAY_B_Write(0);
	

} 



uint8 GetHardwareVals()
{
	uint8 val = 0;
	
	if (LEDR_IN_Read() == 1)
	    val |= LED_IN_RED;
    else
        val &= ~LED_IN_RED;
    
	if (LEDG_IN_Read() == 1)
	    val |= LED_IN_GRN;
    else
       val &= ~LED_IN_GRN; 

	if (SOUND_IN_Read() == 1)
	   val |= SOUNDER_IN;
    else
       val &= ~SOUNDER_IN;
    
    if (TAMPER_IN_Read() == 1)   // Tamper coming from Card Reader
	    val |= TAMPERCR_IN;   //set register bit to 1
    else
        val &= ~TAMPERCR_IN;  //set register bit to 0
   
    if(REED_1_Read() == 1)  // Reed Switch 1 - local ICM tamper
      val |= REED_1_IN;
    else
      val &= ~REED_1_IN;
/*    
    if (REED_2_Read() == 1) // Reed Switch 2 - local ICM tamper  *** THIS SECTION DEFEATED DUE TO IMPROPER VOLTAGE ON REED_2 LINE TO PSOC - GRI 2-3-15
      val |= REED_2_IN;
    else 
      val &= ~REED_2_IN;
*/
      val |= REED_2_IN; // REED_2 is always set to 1 while defeated - remove this when re-enabled
    
    
    if (buttonReleased){
        buttonReleased = 0;
        if(buttonDuration < FCTRYRST_TIME_MS){ //less than 5 seconds
            val |= 0x40; 
            MyI2C_Regs.factory_reset = 0;
        }else if(buttonDuration >=FCTRYRST_TIME_MS && buttonDuration < RSTR_TIME_MS){ //5~45 seconds
            LED_RED_Write(0);
            LED_GRN_Write(0);
            LED_YEL_Write(0);
            val &= 0xBF;  // active reset initiated
            MyI2C_Regs.factory_reset = FACRST_CODE;
        }else if(buttonDuration>=RSTR_TIME_MS){ //45 or more seconds
            LED_RED_Write(0);
            LED_GRN_Write(0);
            LED_YEL_Write(0);
            val &= 0xBF;  // 
            MyI2C_Regs.factory_reset = RESTRE_CODE;
        }
    }else{
        val |= 0x40;
    }
/*    if (SW_Rst_Read() == 0) // factory reset switch
    {  
      if(pwr_cnt >= 5000)   // switch must be held 'on' for 5 seconds
      {
          LED_RED_Write(0);
          LED_GRN_Write(0);
          LED_YEL_Write(0);
          val &= 0xBF;  // active reset initiated
          MyI2C_Regs.factory_reset = 1;
      }
      else
      {
          pwr_cnt++;
          val |= 0x40; 
          MyI2C_Regs.factory_reset = 0;
      }
    }
    else
    {
       pwr_cnt = 0;
       val |= 0x40;
       MyI2C_Regs.factory_reset = 0;
    }
    
    //val = 0;  //turn off - debug only 
*/
    return val;
}

void  HandleOutputs()   // this executes every 1 ms on Tamper_Timer_ISR_Interrupt
{
	char stat = MyI2C_Regs.status_in;
    if( stat & 0x01)
    {
        if((stat & 0x2) == 0x2)
           SetHardwareVals(MyI2C_Regs.acs_inputs);
        
        if(stat & 0x04)
            SendOSDP();
            
        if(stat & 0x08)
            card_ack = 1;    
            
        MyI2C_Regs.status_in = 0; 
    }
   
    
}


void HandleInputs()   // this executes every 1 ms on Tamper_Timer_ISR_Interrupt
{
    char current_t1;
    char current_t2;
    
    /* TAMPER OUT signal to ACS Panel  GRI 1-13-15
       this accounts for configuration of tamper input from card reader  GRI 1-13-15 */
    if( (REED_1_Read() == 0)  
        /*   || (REED_2_Read() == 0)  // disabled GRI 2-4-15 */
        || ((TAMPER_IN_Read() == 0) && (TAMPERCR_POLARITY == 1)) 
        || ((TAMPER_IN_Read() == 1) && (TAMPERCR_POLARITY == 0)) )  
        
    {
       TAMPER_OUT_Write(0); // TAMPER_OUT to ACS is ACTIVE LOW
       LED_RED_Write(0); //LED on
    }
    else
    {
       TAMPER_OUT_Write(1); // TAMPER_OUT to ACS is INACTIVE HIGH
       LED_RED_Write(1); //LED off
    }
    // Tamper LED matches tamper_out signal status (ICM board only)
    
    
    //This section checks for input signal changes

    current_t1 = GetHardwareVals();  // read inputs first time
	if (current_t1 != old)  //change occurred?
	{
        CyDelayUs(100); //delay 100us for debounce
        current_t2 = GetHardwareVals();  // read inputs second time
        
        if (current_t1 == current_t2)    // data is stable?
        {   
            // If Data is stable, change the status reg
            
	        MyI2C_Regs.acs_outputs = current_t2;                //set output reg to MB
            old = current_t2;                                   //store latest value
	        MyI2C_Regs.status |= (STAT_ACS_IN | STAT_CHANGE);   //indicate change in ACS_IN
        }
        else // data changed again
        {
            if (current_t2 == old) // did it return to the old value?
            {
                old = current_t2;  // latest value = same value 
            }
            else // yet another new value, holdoff on reporting changes yet
            {
                old = old; // keep previous value in case there were 2 or more nearly coincident changes
            } 
        } 
	}
    else
    {
        old = current_t1; //store t1 value, no change
    }
}

/* [] END OF FILE */
