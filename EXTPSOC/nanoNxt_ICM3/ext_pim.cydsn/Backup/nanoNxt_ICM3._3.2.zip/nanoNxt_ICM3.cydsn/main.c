/* ========================================
 *
 * NanoNXT Breakout Board
 * Copyright Eyelock.Inc, 2014, 2015
 * All Rights Reserved
 * UNPUBLISHED, LICENSED SOFTWARE.
 * CONFIDENTIAL AND PROPRIETARY INFORMATION
 * 
 * Version History:
 * ================
 * 3.0.0 : Ported Nano Breakout board functionality without HID/F2F.
 * 3.0.1 : Relay output moved from regular output mode to auxillary output mode
 * 3.0.2 : F2F functionality Added.
 * 3.0.3 : HID functionality added using SW UART for 26 bit weigand & SW UART tested on PAC comaptibilty 
 * 3.0.4 : Tamper In is directly routed to Tamper out
 * 3.0.5 : Software Reset button functionality added
 * 3.0.6 : HID functionality modified to support all types of weigand bit formats. 
 * 3.0.7 : Bootloader functionality added.
 * 3.0.8 : Reed Tamper Inverted for Beta.
 * 3.0.9 : Ported code for ICM 3(PSOC 5).
 * 3.1.0 : Bootloader functionality added to ICM3.
 * 3.1.1 : GRI 1-13-15: Tamper signals repaired. Tamper moved to main code block.  Tamper polarity added.
 * 3.1.2 : GRI 1-28-15: Tamper moved to HandleInputs.  I2C bus clock was corrected to be 100kHz to match motherboard (was 400kHz).
 * 3.1.3 : GRI 1-30-15: Removed all "ClearBuffer()" instances.
 * 3.1.4 : GRI 2-02-15: Added ACK bit for card reads to prevent hanging after card read. PSoC will wait for ACK for 5 sec, then re-notify MB.  Changed TamperTimer period to 1ms. 
 * 3.1.5 : GRI 2-04-15: Extensive revision to input signal handler to add noise immunity/debounce (see end of inout.c).
 * 3.1.6 : Added F2F card reader functionality
 * 3.1.7 : Debouncer added to WD0 && Functionality added to detect pulsewidth in F2F
 * 3.1.8 : Added F2F conditionality to turn on timers
 * 3.1.9 : Fixed the bootloader bug for PSOC creator 3.1  Use the debug NxtICM3_bootloader for reference
 * 3.1.10 : Make F2F pulse timing adaptive to the input signal

 * ========================================
*/
#include <project.h>
#include "system.h"
#include "wiegand.h"
#include "power.h"
#include "inout.h"
#include "i2cuart.h"


I2C_Regs MyI2C_Regs;

void SU_Isr(SOFT_UART_STRUCT *s);
 

/***********************************
    Sets the breakout board version.
*************************************/
void SetVersion()
{
    MyI2C_Regs.hw_version[0] = 0x71;
    MyI2C_Regs.hw_version[1] = 0x42;
    MyI2C_Regs.hw_version[2] = 0x0A;
    
    MyI2C_Regs.sw_version[0] = 3;
    MyI2C_Regs.sw_version[1] = 1;
    MyI2C_Regs.sw_version[2] = 15;
}


/*************************************
    Triggers Relay 1 as main output
    in msecs. (Functionality not used now)     
**************************************/
void TriggerRelay1(int waitMSecs)
{
    
    LED_GRN_Write(0) ;
    LED_YEL_Write(0);
	RELAY_A_Write(1);
	CyDelay(waitMSecs);
	LED_GRN_Write(1) ;
    LED_YEL_Write(1) ;
	RELAY_A_Write(0);
	
}

/*************************************
    Triggers Relay 2 as main output
    in msecs. (Functionality not used now)     
**************************************/

void TriggerRelay2(int waitMSecs)
{
    RELAY_B_Write(0);
    LED_GRN_Write(0) ;
    LED_YEL_Write(0);
	RELAY_B_Write(1);
	CyDelay(waitMSecs);
	LED_GRN_Write(1) ;
    LED_YEL_Write(1) ;
	RELAY_B_Write(0);
	
}


/**************************************
  Debug Method: To Set I2C data buffer
***************************************/
void SetBuffer()
{
    MyI2C_Regs.buffer[0] = 0x02;
    MyI2C_Regs.buffer[1] = 0x32;
    MyI2C_Regs.buffer[2] = 0x30;
    MyI2C_Regs.buffer[3] = 0x42;
    MyI2C_Regs.buffer[4] = 0x35;
    MyI2C_Regs.buffer[5] = 0x32;
    MyI2C_Regs.buffer[6] = 0x36;
    MyI2C_Regs.buffer[7] = 0x42;
    MyI2C_Regs.buffer[8] = 0x35;
    MyI2C_Regs.buffer[9] = 0x42;
    MyI2C_Regs.buffer[10] = 0x31;
    MyI2C_Regs.buffer[11] = 0x77;

}

void ClearBuffer()
{
    int i;
    for(i=0; i < 20; i++)
      MyI2C_Regs.buffer[i] = 0;
}

/***********************************************
            Weigand -HID Protocol
  Procedure to send weigand data in serial format
  Baud Rate: 57600 Databits: 8 
  Stop Bits: 2 Parity: Even 
  Bits to transmit : 18 bytes
  Zero paddings to the left before the weigand data 

************************************************/

void SendHID_SP533()
{
    
    Clock_5_SetDividerValue(625); //set the baud rate to default 9600
    UART_ACS_Init();
    CyDelay(20);
    Mode_Sel_ACS_Write(0); //set io chip to RS232
    TX_EN_Write(1);
    UART_ACS_LoadTxConfig();
    CyDelay(1); //Driver Output Enable Time, do not reduce. 
    UART_ACS_PutArray(MyI2C_Regs.buffer,MyI2C_Regs.data_length/8); 
    CyDelay(5); //minmum 4m
    UART_ACS_LoadRxConfig();
    TX_EN_Write(0);

}


void SendHID()
{
    Tamper_Timer_Stop();
    
    char serialOut[20];
	char tmp;
	int i,j;
	int padBytes;
    int xbytes;
    int ybits;
    MyI2C_Regs.data_length = 26;
    xbytes =  MyI2C_Regs.data_length / 8;
    ybits =   MyI2C_Regs.data_length - (xbytes*8);
    padBytes = 18  -  xbytes;
    
    if(ybits  >  0)
	   padBytes = padBytes - 1;
    
    for (i = 0;i < padBytes;i++)
    {
       serialOut[i] = 0x00;
       SU_PutChar(&s,serialOut[i]);
      
    }
	
    serialOut[14] = 0x01 << ybits;
	tmp = MyI2C_Regs.buffer[0] & (0xFF << (8-ybits));		
    tmp = tmp >> (8-ybits);
	serialOut[i] |= tmp; 
	SU_PutChar(&s,serialOut[i]);
	i++;
		
	for (j = 1; j< (18- padBytes); j++)
	{
		serialOut[i] = (MyI2C_Regs.buffer[j-1] << ybits );// & (0xFF << ybits);
		tmp = (MyI2C_Regs.buffer[j] >> (8-ybits));// & (0xFF >> (8-ybits));
		serialOut[i] |= tmp;
		SU_PutChar(&s,serialOut[i]);
		i++;
	}
    
    Tamper_Timer_Start();    
    serialOut[i] = 0x00;
}


void InitOSDP(){
    
    //initialize the OSDP
    Clock_5_Enable();
    Clock_5_SetDividerValue(625); //set the baud rate to default 9600
    UART_ACS_Start();
    ClearOsdpBuffer();
    
    Clock_6_Enable();
    Clock_6_SetDividerValue(625); //set the baud rate to default 9600
    UART_READER_Start();
    ClearOsdpReaderBuffer();
    
    isr_keepalive_StartEx(KeepAliveInterruptHandler);
    OSDPReaderTimer_Start();
    
}

 /***********************************************
     Debug Code : Software UART for PAC Protocol
  ************************************************
 void SendPACTest()
{
      int i,j;
    LED_GRN_Write(0);
    LED_YEL_Write(1);
  
    for( i = 0; i < 20; i++)
    {
        for( j= 0; j < 12 ; j++)
        {
            char c = MyI2C_Regs.buffer[j];
         SU_PutChar(&s,c);
        }
      
    }

    LED_GRN_Write(1);
    LED_YEL_Write(1);
}

****************************************************/




char osdp_mode;

/****************************************
   Method to handle commands
   coming from device

*****************************************/
void HandleCommand()
{
    char cmd;
    cmd = MyI2C_Regs.cmd;
    if (cmd != CMD_BOOTLOAD && cmd != CMD_READ_CARD) MyI2C_Regs.osdp_reader_cmd = OSDP_NONE;
    
	switch (cmd)
    {
        case CMD_BOOTLOAD:
            BootloadableI2C_Load();  //yqh
             break;
        
        case CMD_TRIGGER_RELAY1:
		        TriggerRelay1(MyI2C_Regs.data_length*1000); //Trigger relay and wait for x secs
                MyI2C_Regs.cmd = 0;  
				break;
                
        case CMD_TRIGGER_RELAY2:
		        TriggerRelay2(MyI2C_Regs.data_length*1000); //Trigger relay and wait for x secs
                MyI2C_Regs.cmd = 0;  
				break;
                
        case CMD_READ_CARD:
                
                if (MyI2C_Regs.osdp_cmd != OSDP_NONE || MyI2C_Regs.osdp_reader_cmd != OSDP_NONE )
                {
                    osdp_mode = 1;
                    break; //goto process osdp message
                }
                osdp_mode = 0;
                
                if(MyI2C_Regs.data_length >= 26)//Read Weigand
                {
                    LED_GRN_Write(1);
                    OptSelect_Write(1);
                    ClearBuffer(); // added here - GRI 2/2/15
                    while(ReadWeigand(MyI2C_Regs.data_length) == 0)
                    {
                        if(MyI2C_Regs.cmd !=CMD_READ_CARD ) 
                            break;
                    };
                    
                    LED_GRN_Write(0);
                    
                }
                else if(MyI2C_Regs.data_length == 12)//Read PAC
                {
                    LED_GRN_Write(1);
                    ClearBuffer(); // added here - GRI 2/2/15
                    SetupUART(PAC);
                    while(ReadPAC()== 0)
                    {
                        if(MyI2C_Regs.cmd !=CMD_READ_CARD )
                        break;
                    }
                    LED_GRN_Write(0);
                    OptSelect_Write(1);

                }
                else//Read F2F
                {
                    activate_f2ftimer = 1;

                    LED_GRN_Write(1);
                    OptSelect_Write(1);
                    ClearBuffer(); // added here - GRI 2/2/15
                    while(ReadF2F() == 0)
                    {
                        if(MyI2C_Regs.cmd !=CMD_READ_CARD ) 
                            break;
                    };
                    LED_GRN_Write(0);
                }
                break;
	    
        case CMD_SEND_PAC:
                LED_YEL_Write(1);
                SetupUART(PAC);
                SendPAC();
                MyI2C_Regs.cmd = 0;
                LED_YEL_Write(0);
				break;
                
        case CMD_SEND_F2F:
                LED_YEL_Write(1);
                OptSelect_Write(1);
				SendF2F();
                MyI2C_Regs.cmd = 0;
                LED_YEL_Write(0);
			    break;        
                
        case CMD_SEND_HID:
               LED_YEL_Write(1);
               OptSelect_Write(1);
//               SendHID_SP533();
               SendHID();
               MyI2C_Regs.cmd = 0;
               LED_YEL_Write(0);
			   break;
            
        case CMD_SEND_WEIGAND:
                if (MyI2C_Regs.data_length){
                    LED_YEL_Write(0);
                    OptSelect_Write(1);
    				SendWeigand(MyI2C_Regs.data_length);
                    MyI2C_Regs.cmd = 0;
                    LED_YEL_Write(1);
                }
				break;  
        default:
                LED_RED_Write(0); //error
                break;
	}     
	
}

extern ReaderBuf readerSendBuffer;
extern PanelBuf panelSendBuf;

/****************************************
   Method to handle OSDP commands
   coming from device

*****************************************/
void HandleOSDP()
{
//    int i; 
 
    //Now, Handle the Reader Messages
    if (MyI2C_Regs.osdp_reader_cmd != 0){
    	switch (MyI2C_Regs.osdp_reader_cmd)
        {
            case OSDP_NONE:
            case OSDP_BUSY:
                break;
            case OSDP_SEND:
                SetOSDPKeepALive();
//                ClearOsdpReaderBuffer();
                MyI2C_Regs.osdp_reader_cmd = OSDP_READ;

//                SendOSDPReader();
//                MyI2C_Regs.osdp_reader_cmd = OSDP_NONE; //ready for the next I2c message               
              break;
            case OSDP_READ:
                break;
            case OSDP_RATE:
                SetOSDPReaderSpeed();
//                SetOSDPKeepALive();  
                //Fang said that the message is already in the i2c register.
                MyI2C_Regs.osdp_reader_cmd = OSDP_SEND;
                break;
            default:;
/*                for (i=0; i<3; i++){
                    LED_RED_Write(0); //display error
                    LED_YEL_Write(0);
                    CyDelay(500);
                    LED_RED_Write(1); //error
                    LED_YEL_Write(1);
                    CyDelay(500);
                }*/
//                MyI2C_Regs.osdp_reader_cmd = OSDP_NONE; //ready for the next I2c message               
        }
    }
    
    // check to see if it need send the reader again
    if((OSDPReaderTask >> OSDP_SEND_READER) & 0x01){
        OSDPReaderTask &= ~(0x01 << OSDP_SEND_READER); //clear flag
        if ( readerSendBuffer.len > 0){
            LED_RED_Write(0);
            SendOSDPReader();
            LED_RED_Write(1);
        }
    }
    
   
    //Panel Messages
    if (MyI2C_Regs.osdp_cmd){
    	switch (MyI2C_Regs.osdp_cmd)
        {
            case OSDP_NONE:
            case OSDP_BUSY:
                 break;
            case OSDP_SEND:
                copyI2CPanelBuf(&panelSendBuf);
                SendOSDP();
                 break;
            case OSDP_READ:
                 break;
            case OSDP_RATE:
                SetOSDPRate();
                 break;
            default:;
        }
    }
    
    
    // check if anything comes in
    ReadOSDPReader();
    ReadOSDP();
}


int main()
{
    /* Intializing the variables */
    char cmd;
    int wait_for_ack; // card read acknowledge
    int ack_time_cnt; // counter for acknowledge timeout
    
    CyGlobalIntEnable;  /* Uncomment this line to enable global interrupts. */

//    /* Intializing the Timers */
    UART_TIMER_Start();
	UART_TIMER_ISR_StartEx(UART_TIMER_ISR_Interrupt);

 
    Tamper_Timer_ISR_StartEx(Tamper_Timer_ISR_Interrupt);
    Tamper_Timer_Start();
    Timeout_Timer_Isr_StartEx(Timeout_Timer_Isr_Interrupt);

    /*F2F*/
    f2f_pulsewidth = 0;
    isr_F2F_edge_StartEx(isr_F2F_edge_Interrupt);
    
	/* Starting EZI2C */
	EZI2Cs_Start();
    EZI2Cs_SetBuffer1(sizeof(MyI2C_Regs), sizeof(MyI2C_Regs), (volatile uint8 *) &MyI2C_Regs );
    
    /* Starting UART for PAC & HID */
    UART_1_Start();
    SU_Start(&s,1,PARITY_EVEN,1);
    
    /* Turning off both LEDS */
    LED_GRN_Write(1); // LED for signaling Output
    LED_YEL_Write(1); // LED for signaling Input
    LED_RED_Write(1); // turn off tamper LED
    
    /* Intializing the I2C Reg value */
    MyI2C_Regs.cmd =0;
    MyI2C_Regs.status =0;
    MyI2C_Regs.status_in =0;
    MyI2C_Regs.acs_outputs = 0;
    MyI2C_Regs.data_length = 0;
    MyI2C_Regs.factory_reset = 0;
    MyI2C_Regs.osdp_reader_cmd = OSDP_RATE;
    MyI2C_Regs.osdp_reader_rate = 1;   
   
    SetHardwareVals(8);  // TAMPER_POL defaulted to 1 (normal config with active tamper = 0)
    
    SetVersion();
    
    // initialize card reader tamper polarity bit:  1=normal
    // This is only for TEST and must be set by webconfig/motherboard.
    // TAMPERCR_POLARITY = 1;
    activate_f2ftimer = 0;
    card_ack = 0;
    
    InitOSDP();
    
    /* push button */
    buttonPressed=0;
    buttonReleased=0;
    buttonDuration=0;
    isr_SW_Rst_Start(); 
    

    while(1)
    {
    //Infinite While Loop for handling device req
        wait_for_ack = 0;
        ack_time_cnt = 0;
        
        
        cmd = MyI2C_Regs.cmd;   // load command
        
        if (cmd !=0)  // command exists if register not 0
        {
  		    if (cmd == CMD_READ_CARD) {wait_for_ack = 1;}   // flag to trigger wait for ack from motherboard after read of buffer
            HandleCommand();
        }
        
        HandleOSDP();
        
        if ((wait_for_ack == 1) & (card_in_buf == 1))  // card read requires ack from motherboard
        {
            
            while (card_ack == 0)   // waiting for card read acknowledge here
            {
                CyDelay(10);    //10ms
                ack_time_cnt++;  // increment time counter every 10ms while waiting for ack
                if (ack_time_cnt >= 500)    // if 5000 ms, re-notify and break.
                {
                    
                    MyI2C_Regs.status |= STAT_CHANGE | STAT_CARD_IN ;   // if timeout, set status bit a second time to notify motherboard
                    wait_for_ack = 0;
                    ack_time_cnt = 0;
                    break;
                }
            }
            card_in_buf = 0;
            wait_for_ack = 0;
        } 

        if (osdp_mode) CyDelay(0);
        else CyDelay(50);    //up to 50ms Sec delay for sending out signals. 
 
    } //while
}

/* [] END OF FILE */
