/* ========================================
 *
 * Copyright YOUR COMPANY, THE YEAR
 * All Rights Reserved
 * UNPUBLISHED, LICENSED SOFTWARE.
 *
 * CONFIDENTIAL AND PROPRIETARY INFORMATION
 * WHICH IS THE PROPERTY OF your company.
 *
 * ========================================
*/

#include "project.h"

int mot_start;
int mot_decel_start;
int mot_target,half_dist;
uint8 mot_active =0;
uint8 mot_homed=0;
int mot_pos;

#define ACCEL 40
#define MAX_V 230
#define MIN_SPEED_ACCEL 55
#define MIN_SPEED_DECEL 55
#define HOME_SPEED 50
#define HOME_I 120
#define RUN_I 220
#define RUN_I_COUNTER_SPRING 250
#include "math.h"
#include "motor.h"

int MotGetPos(void)
{
    return mot_pos;
}

#define TO_HOME_STEP 1000
void MotHome()
{
    int x,lp=0;
    int to=TO_HOME_STEP;
    IDAC_1_SetValue(HOME_I);
   
    PWM_M_WriteCompare1(HOME_SPEED);
    CW_Write(1);
    STEP_COUNT_WriteCounter(10000);
    while(((x=STEP_COUNT_ReadCounter())<10008) && (to--))
        CyDelayUs(100);
    
    
    //add timeout for homing
    while (1)
        {
            lp=lp+1;
            if (lp>3000)
        if (Comp_ISENSE_GetCompare()==1)
           {
            mot_active=0;
            PWM_M_WriteCompare1(0);
            mot_pos=0;
            mot_homed=1;
            break;
           }
        }
}
unsigned short isqrt(unsigned long a) {
    unsigned long rem = 0;
    int root = 0;
    int i;

    for (i = 0; i < 16; i++) {
        root <<= 1;
        rem <<= 2;
        rem += a >> 30;
        a <<= 2;

        if (root < rem) {
            root++;
            rem -= root;
            root++;
        }
    }

    return (unsigned short) (root >> 1);
}
uint8 MotMoveRel(int steps)
{
    if ( mot_active)
      return 0;
    if (steps==0)
      return 1;
     IDAC_1_SetValue(RUN_I);
    mot_pos+=steps;
    if (steps>0)
    {
       CW_Write(0);
    IDAC_1_SetValue(RUN_I_COUNTER_SPRING);
    }
    else
       {
        CW_Write(1);
        steps=-steps;
        IDAC_1_SetValue(RUN_I);
       }
    
    STEP_COUNT_WriteCounter(10000);
    mot_start=STEP_COUNT_ReadCounter();
    mot_target = mot_start +steps;
    half_dist = mot_start +steps/2;
    mot_active=1;
    return 1;
}
int last_p, last_x;
int MotTask()
{
   int x,p;
    
   if (mot_active)
       {
        x=STEP_COUNT_ReadCounter();
        if (Comp_ISENSE_GetCompare()==1)
           {
            mot_active=0;
            PWM_M_WriteCompare1(0);
            return 0;
           }
       
       if (x<half_dist)
            p = isqrt((x-mot_start)*ACCEL*2)+MIN_SPEED_ACCEL;
       else
               if (mot_target-x>0)
                    p = isqrt((mot_target-x)*ACCEL*2)+MIN_SPEED_DECEL;
               else
                    p=0;
       if (p>MAX_V)
          p=MAX_V;
       PWM_M_WriteCompare1(p);
       if (x>=mot_target)
          {
          mot_active=0;
          PWM_M_WriteCompare1(0);
          }
         last_p=p;
         last_x=x;
        return 1;
     }

    return 0;
}

/* [] END OF FILE */
