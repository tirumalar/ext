/* ========================================
 *
 * Copyright YOUR COMPANY, THE YEAR
 * All Rights Reserved
 * UNPUBLISHED, LICENSED SOFTWARE.
 *
 * CONFIDENTIAL AND PROPRIETARY INFORMATION
 * WHICH IS THE PROPERTY OF your company.
 *
 * ========================================
*/
void  HandleInputs();
void  HandleOutputs();
void  SetOutputBits(int b);
void  ClearOutputBits(int b);
void  SetHardwareVals(char val);


/* [] END OF FILE */
