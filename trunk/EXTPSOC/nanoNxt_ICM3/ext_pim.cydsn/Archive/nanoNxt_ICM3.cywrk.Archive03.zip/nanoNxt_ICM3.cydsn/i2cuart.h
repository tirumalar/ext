/* ========================================
 *
 * Copyright YOUR COMPANY, THE YEAR
 * All Rights Reserved
 * UNPUBLISHED, LICENSED SOFTWARE.
 *
 * CONFIDENTIAL AND PROPRIETARY INFORMATION
 * WHICH IS THE PROPERTY OF your company.
 *
 * ========================================
*/
#ifndef __I2CUART_INCLUDED__   
#define __I2CUART_INCLUDED__  
#include <CyLib.h>
    
//#ifdef __cplusplus
//extern "C" {
//#endif
    
void SendPAC();
int ReadPAC();
void SetupUART(char);


/* OSDP Single */
void ClearOsdpBuffer(void);
void SendOSDP(void);
void ReadOSDP(void);
void SetOSDPRate(void);

/* OSDP Dual */
CY_ISR(KeepAliveInterruptHandler);
void ClearOsdpReaderBuffer(void);
void SendOSDPReader(void);
void ReadOSDPReader(void);
void SetOSDPReaderSpeed(void);
void SetOSDPKeepALive(char *, unsigned char);
void SendOSDPReaderKeepALive(void);



//#ifdef __cplusplus
//}
//#endif

#endif 

/* [] END OF FILE */
