/* ========================================
 *
 * Copyright YOUR COMPANY, THE YEAR
 * All Rights Reserved
 * UNPUBLISHED, LICENSED SOFTWARE.
 *
 * CONFIDENTIAL AND PROPRIETARY INFORMATION
 * WHICH IS THE PROPERTY OF your company.
 *
 * ========================================
*/
#ifndef __SYSTEM_INCLUDED__   
#define __SYSTEM_INCLUDED__  

// GRI 1-13-2015 - Revised for 3.1.1; TAMPERCR_POL name changed to indicate polarity setting for CR Tamper in webconfig. 

#include "softuart.h"

#define BUFFER_LENGTH 20
#define OSDP_BUFFER_LENGTH 128
#define OSDP_READER_BUFFER_LENGTH 48
/* I2C Regs Starts at 0x38 */

typedef struct I2C_Regs {    // I2C interface structure
	char status;            //1
    char status_in;
	char cmd;           //commands from motherboard
    char data_length;
	char acs_outputs;   //data to motherboard
    char acs_inputs;    //data from motherboard     6
	char buffer[BUFFER_LENGTH];
    char dummy[BUFFER_LENGTH*2];
    char factory_reset;             //67
    char sw_version[3];
    char hw_version[3];
    unsigned char osdp_cmd;         //74
    unsigned char osdp_status;      
    unsigned char osdp_data_length;
    unsigned char osdp_rate;        //77
    unsigned char osdp_buffer[OSDP_BUFFER_LENGTH];  
    unsigned char osdp_reader_cmd;          //206
    unsigned char osdp_reader_data_length;
    unsigned char osdp_reader_rate;
    unsigned char osdp_reader_buffer[OSDP_READER_BUFFER_LENGTH];
}I2C_Regs;

extern I2C_Regs MyI2C_Regs;
SOFT_UART_STRUCT s;

/* Auxillary IO variables */
char currentAccessType;
char old;
int TAMPERCR_POLARITY;

/* Dual auth variables */
int card_ack;   // added GRI 2/2/15
int card_in_buf;    // added GRI 2/3/15

/* F2F card read variables */
char got_pulse;
int f2f_pulsewidth;
int timeout_cnt;
char activate_f2ftimer;

/* OSDP task flags */
extern unsigned char OSDPReaderTask;

/* Button pressed */
extern char buttonPressed;
extern char buttonReleased;
extern long buttonDuration;

/* COMMANDS */

#define CMD_BOOTLOAD        1
#define CMD_READ_CARD       2
#define CMD_TRIGGER_RELAY1  3
#define CMD_TRIGGER_RELAY2  4
#define CMD_SEND_F2F        5
#define CMD_SEND_HID        6
#define CMD_SEND_PAC        12
#define CMD_SEND_WEIGAND    26


/* ACS INPUT VALUES */
#define LED_IN_RED      0x1
#define LED_IN_GRN      0x2
#define SOUNDER_IN      0x4
#define TAMPERCR_IN     0x8
#define REED_1_IN       0x10
#define REED_2_IN       0x20
#define PWR_RESET       0x40

/* ACS OUTPUT VALUES */
#define LED_OUT_RED   0x1
#define LED_OUT_GRN   0x2
#define SOUNDER_OUT   0x4
#define TAMPERCR_POL  0x8   //Name changed to indicate polarity setting for CR Tamper in webconfig GRI 1/2015
#define RELAY_1_OUT   0x10
#define RELAY_2_OUT   0x20

/* STATUS VALUES */
#define STAT_CHANGE  1
#define STAT_CARD_IN 2
#define STAT_ACS_IN 4 


/* INPUT STATUS VALUES */
#define STAT_CHANGE 1
#define STAT_ACS_OUT 2
#define STAT_OSDP_OUT 4
#define STAT_CARD_ACK 8


/* INTERNAL DEFINE */
#define PAC 12
#define HID 26

/* OSDP CMD and READER CMD*/
#define OSDP_NONE           0
#define OSDP_SEND           1
#define OSDP_READ           2
#define OSDP_RATE           3

/* OSDP STATUS */
#define OSDP_DATA_SENT              0x01
#define OSDP_DATA_IN_READY          0x02
#define OSDP_READER_DATA_SENT       0x10
#define OSDP_READER_DATA_IN_READY   0x20

/* OSDP RATE */
#define OSDP_9600   1
#define OSDP_19200  2
#define OSDP_38400  3
#define OSDP_115200 4

/* OSDP task */
//#define OSDP_CP_ENABLED     0
//#define OSDP_READER_ENABLED 1
#define OSDP_SEND_READER    2

/* Factory Reset */
#define FACRST_CODE 0x0F
#define RESTRE_CODE 0x99
#define FCTRYRST_TIME_MS 5000
#define RSTR_TIME_MS 45000

/*I2C Reg Address 

status_output       0           0H
status_input        1           1
command             2           2
data_length         3           3
acs_outputs         4           4
acs_inputs          5           5
buffer[20]          6           6
dummy               26          1A
sw_version[3]       67          43
hw_version[3]       70          46
osdp_cmd;           73          49
osdp_status;        74          4A
osdp_data_length;   75          4B
osdp_rate;          76          4C
osdp_buffer         77          4D
osdp_reader_cmd     205         CD
osdp_reader_data_length 206     CE
osdp_reader_rate    207         CF
osdp_reader_buffer  208         D0
                    336         150H

*/



#endif
/* [] END OF FILE */

