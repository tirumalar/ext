/* ========================================
 *
 * Copyright YOUR COMPANY, THE YEAR
 * All Rights Reserved
 * UNPUBLISHED, LICENSED SOFTWARE.
 *
 * CONFIDENTIAL AND PROPRIETARY INFORMATION
 * WHICH IS THE PROPERTY OF your company.
 *
 * ========================================
*/
#ifndef __I2CUART_INCLUDED__   
#define __I2CUART_INCLUDED__  
    
//#ifdef __cplusplus
//extern "C" {
//#endif
    
void SendPAC();
int ReadPAC();
void SetupUART(char);

void ClearOsdpBuffer(void);
void SendOSDP(void);
int ReadOSDP(void);
void SetOSDPRate(void);

void ClearOsdpReaderBuffer(void);
void SendOSDPReader(void);
int ReadOSDPReader(void);
void SetOSDPReaderSpeed(void);
void SetOSDPKeepALive(char *, unsigned char);
void SendOSDPReaderKeepALive(void);

//#ifdef __cplusplus
//}
//#endif

#endif 

/* [] END OF FILE */
