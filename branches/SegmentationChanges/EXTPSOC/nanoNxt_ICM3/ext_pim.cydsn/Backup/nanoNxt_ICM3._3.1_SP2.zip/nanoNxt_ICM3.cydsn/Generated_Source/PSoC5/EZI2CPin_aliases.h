/*******************************************************************************
* File Name: EZI2CPin.h  
* Version 2.10
*
* Description:
*  This file containts Control Register function prototypes and register defines
*
* Note:
*
********************************************************************************
* Copyright 2008-2014, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions, 
* disclaimers, and limitations in the end user license agreement accompanying 
* the software package with which this file was provided.
*******************************************************************************/

#if !defined(CY_PINS_EZI2CPin_ALIASES_H) /* Pins EZI2CPin_ALIASES_H */
#define CY_PINS_EZI2CPin_ALIASES_H

#include "cytypes.h"
#include "cyfitter.h"



/***************************************
*              Constants        
***************************************/
#define EZI2CPin_0		(EZI2CPin__0__PC)
#define EZI2CPin_1		(EZI2CPin__1__PC)

#define EZI2CPin_scl		(EZI2CPin__scl__PC)
#define EZI2CPin_sda		(EZI2CPin__sda__PC)

#endif /* End Pins EZI2CPin_ALIASES_H */

/* [] END OF FILE */
