/* ========================================
 *
 * Copyright YOUR COMPANY, THE YEAR
 * All Rights Reserved
 * UNPUBLISHED, LICENSED SOFTWARE.
 *
 * CONFIDENTIAL AND PROPRIETARY INFORMATION
 * WHICH IS THE PROPERTY OF your company.
 *
 * ========================================
*/
#ifndef __I2CUART_INCLUDED__   
#define __I2CUART_INCLUDED__  
#include <CyLib.h>
#include "system.h"
    
//#ifdef __cplusplus
//extern "C" {
//#endif
    
    
typedef struct  {
    unsigned char buf[OSDP_BUFFER_LENGTH];
    unsigned char len;
    unsigned char pending;
}PanelBuf;   
 
typedef struct  {
    unsigned char buf[OSDP_READER_BUFFER_LENGTH];
    unsigned char len;
}ReaderBuf;   

   
    
void SendPAC();
int ReadPAC();
void SetupUART(char);


/* OSDP Single */
void copyI2CPanelBuf();
void ClearOsdpBuffer(void);
void SendOSDP(void);
void ReadOSDP(void);
void SetOSDPRate(void);

/* OSDP Dual */
CY_ISR(KeepAliveInterruptHandler);
void ClearOsdpReaderBuffer(void);
void SendOSDPReader(void);
void ReadOSDPReader(void);
void SetOSDPReaderSpeed(void);
void SetOSDPKeepALive(void);
//void SendOSDPReaderKeepALive(void);



//#ifdef __cplusplus
//}
//#endif

#endif 

/* [] END OF FILE */
