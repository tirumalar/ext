/* ========================================
 *
 * Copyright YOUR COMPANY, THE YEAR
 * All Rights Reserved
 * UNPUBLISHED, LICENSED SOFTWARE.
 *
 * CONFIDENTIAL AND PROPRIETARY INFORMATION
 * WHICH IS THE PROPERTY OF your company.
 *
 * ========================================
*/

// GRI 2-2-15: Modified ReadWiegand.

#include <project.h>
#include "system.h"



void SendWeigand(int nBits)  //Function to send Wiegand Data
{
	int x,y;
	char  d1;
    char count = 0;

    
	/*                        Wiegand protocol
	    A pulse width of 50us to define data
	    A wait period of 2ms after transmitting the above defined pulse
    */
	

	for (x=0; x< 20; x++) // Loop over data written from the OMAP
	{
        d1 = MyI2C_Regs.buffer[x];
		for (y=0; y <8; y++)  //Transmit each bit at a time
		{	
			count = count + 1;
            if (count > nBits) //26 bit Wiegand; so terminate at 26 bits
			{
                OptSelect_Write(2);
			    PS_D1_Write(0);
				return;
			}

		    if ((d1&0x80)) // Check if it a 1 or a 0
			{
                OptSelect_Write(2); //10 for select & D0
				PS_D1_Write(1);
			}
			else
			{
                OptSelect_Write(3); //10 for select & D0
				PS_D1_Write(0);
			}			    

            
            CyDelayUs(50);
            
            OptSelect_Write(2);
			PS_D1_Write(0);
			d1=d1<<1;
            
           
             CyDelay(2);

		}
        
	}
  
}


int ReadWeigand(int nBits)
{
    int bitCount=0;
    int byteCount=0;
   
    char WD0 = Pin_WD0_Read() ;
    char WD1 = Pin_WD1_Read();
    card_in_buf = 0;
    
    if( WD0 == 0 || WD1 == 0)
    {
        while(byteCount*8+bitCount < nBits)
        {
           //Read D0 line for input, if yes wait for 50 usec for data to end
           WD0 = Pin_WD0_Read();
           WD1 = Pin_WD1_Read();
           if(WD0 == 0)
           {
             while(WD0 != 1){WD0 = Pin_WD0_Read();}
             
             bitCount++;

           }
        
            //Read D1 line for input, if yes wait for 50 usec for data to end
            //and write 1 to the bit in the buffer at the right position.            
           else if(WD1 == 0)
           {
             while(WD1 != 1){WD1 = Pin_WD1_Read();}
             MyI2C_Regs.buffer[byteCount] |= (0x01 << (7-bitCount));  //write a 1 to current buffer word 
             bitCount++;

           }
        
            //Reset bitCount
            if (bitCount > 7)
			{
				bitCount = 0;
				byteCount++;
			}
            
        }
        MyI2C_Regs.cmd = 0;
        card_in_buf = 1;
        MyI2C_Regs.status |= STAT_CHANGE | STAT_CARD_IN ;
        
        return 1;
    }
    card_in_buf = 0;
    return 0;
}

void SendF2F()
{
	int x,b,z,len;
	char  d0;
	char aPRT0DRa;
	unsigned char f2f[28];
    char flag=0;
/*	//debug code	
    MyI2C_Regs.buffer[0] = 0;
    MyI2C_Regs.buffer[1] = 0xD1;
    MyI2C_Regs.buffer[2] = 0xE1;
    MyI2C_Regs.buffer[3] = 0xF9;
    MyI2C_Regs.buffer[4] = 0x80;
    MyI2C_Regs.data_length = 5;
*/    
    
    len = MyI2C_Regs.data_length + 3;
	//Loop over data written by OMAP, 40 bit no facility card
	//Zeros are transmitted as two transitions, with a pulse width of 1.1 ms
	//Ones are transmitted as four transitions, with a pulse width of 0.55 ms
	for (x=0; x< len; x++)
	{   	
		d0 = MyI2C_Regs.buffer[x];	
        aPRT0DRa = 0;
		f2f[2*x] = 0;
		f2f[2*x + 1] = 0;		 
		for (b=0; b <4; b++)    //higher 4 bits
		{	   	  
			if (d0&0x80)    //it is a 1
			{      
				if (flag == 0)  //previous level is 0
				{	   	
					flag = 0;
					aPRT0DRa |= 0x02;	   	   		   
				}
				else            //previous level is 1
				{
					aPRT0DRa |= 0x01;
					flag = 1;
				}
			}
			else    //it is a 0
			{
				if (flag == 0)  //previous level is 0
				{
					aPRT0DRa |= 0x03;
					flag = 1;
				}
				else    //previous level is 1
				{
					flag = 0;
				}		   
			}

			if (b < 3)
				aPRT0DRa <<= 2; //go next bit

			d0 <<= 1;   //go next bit
		}
		f2f[2*x] = aPRT0DRa;

		aPRT0DRa = 0;	
		for (b=0; b <4; b++)    //lower 4 bits
		{	   	  
			if (d0&0x80)
			{      
				if (flag == 0)
				{	   	
					flag = 0;
					aPRT0DRa |= 0x02;	   	   		   
				}
				else
				{
					aPRT0DRa |= 0x01;
					flag = 1;
				}
			}
			else
			{
				if (flag == 0)
				{
					aPRT0DRa |=0x03;
					flag = 1;
				}
				else
				{
					flag = 0;
				}		   
			}

			if (b < 3)
				aPRT0DRa<<=2;

			d0<<=1;
		}
		f2f[2*x + 1] = aPRT0DRa;
	}

	//Use 8-bit timer to set up the pulse widths
	//Use the buffered data from above where we already set up the data specific pulses and send them out sequentially.
	aPRT0DRa = 0;
	for (z=0;z<2*len;z++)      //24
	{
		d0 = f2f[z];
		f2f[z]=0;
		for (b=0; b <8; b++)
		{
			if (d0&0x80)
            {
                PS_D0_Write(1);
                OptSelect_Write(2); 
			}
            else
            {
                OptSelect_Write(3);
                PS_D0_Write(0);
             }   
//            CyDelayUs(1000);
            CyDelayUs(400);
			d0<<=1;
		}
	}
    OptSelect_Write(2);
    PS_D0_Write(0);    //set output to high after done
}


/* F2F card read variables */
uint8 f2fdebugled=1;

/* F2F reader acknowledgement */
char f2f_acknowledge_active;
char f2f_ack_delay_cnt;

int ReadF2F()
{
    int bitCount;
    int byteCount;
    int hp;
    char nbit;
    int i;
    unsigned char started;
    int width;
    
    // enable ack line
    PS_D1_Write(0);

    for(i =0; i < 20; i++)
            MyI2C_Regs.buffer[i] = 0;
            
    hp = 20;
    byteCount = 0;  
    nbit = 0;
    bitCount = 1;
    started = 0;
    card_in_buf = 0;
           
    timeout_cnt = 0;
    while( byteCount <  11)
    {
        width = f2f_pulsewidth;             
        if(width != 0)
        {
            LED_GRN_Write(1);
            isr_F2F_edge_Disable();
            f2f_pulsewidth = 0;
            isr_F2F_edge_Enable();
            if (bitCount > 7)
            {
                bitCount = 0;
                byteCount++;
            }
            if(started == 0 && width > 7 && width < 0x40)
            {
                hp = (width + hp)>>1;  //average out
            }
            /* A pulse width of 1msec is considered a 0 && two pulse widths of 0.5 msec is consdiered as 1
               Timeout timer is configured to update timeoutcnt every 50 usecs      */
            if( width < ((int)(0.75*hp)))
            {
                nbit++;
                if(nbit > 1)
                {
                  MyI2C_Regs.buffer[byteCount] |= (0x01 << (7-bitCount));   
                  bitCount++;
                  nbit = 0; 
                  started = 1;
                }
            } 
            else if(started == 1 && width >= ((int)(0.75*hp)) && width < 0x40 ) {
                nbit = 0;
                bitCount++;
            }
        } //got pulse
    }  //while
                     LED_GRN_Write(1);
    
    MyI2C_Regs.osdp_reader_data_length = byteCount;  //debug
    
    Timeout_Timer_Stop();
    f2f_pulsewidth = 0;
    
    for(i =0; i < 20; i++)  //debugging, yqh remove later
            MyI2C_Regs.osdp_reader_buffer[i] = MyI2C_Regs.buffer[i];

    if(byteCount < 9)
    {
        MyI2C_Regs.data_length = 0;  //stay at the f2f mode
        return 0;
    }
    else
    {
        MyI2C_Regs.data_length = 10;
        MyI2C_Regs.cmd = 0;  //to prevent send again
        MyI2C_Regs.status |= STAT_CHANGE | STAT_CARD_IN ;
        card_in_buf = 1;
        return 1;
    }
}




/* [] END OF FILE */
