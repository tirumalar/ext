/* ========================================
 *
 * Copyright YOUR COMPANY, THE YEAR
 * All Rights Reserved
 * UNPUBLISHED, LICENSED SOFTWARE.
 *
 * CONFIDENTIAL AND PROPRIETARY INFORMATION
 * WHICH IS THE PROPERTY OF your company.
 *
 * ========================================
*/

void SendPAC();
void SendOSDP();

void SetupUART(char accessType);

int ReadPAC();
int ReadOSDP();
/* [] END OF FILE */
