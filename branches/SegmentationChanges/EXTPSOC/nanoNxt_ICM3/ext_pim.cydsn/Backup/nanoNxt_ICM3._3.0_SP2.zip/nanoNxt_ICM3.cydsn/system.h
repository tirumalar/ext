/* ========================================
 *
 * Copyright YOUR COMPANY, THE YEAR
 * All Rights Reserved
 * UNPUBLISHED, LICENSED SOFTWARE.
 *
 * CONFIDENTIAL AND PROPRIETARY INFORMATION
 * WHICH IS THE PROPERTY OF your company.
 *
 * ========================================
*/

// GRI 1-13-2015 - Revised for 3.1.1; TAMPERCR_POL name changed to indicate polarity setting for CR Tamper in webconfig. 

#include "softuart.h"

#define BUFFER_LENGTH 20

/* I2C Regs Starts at 0x38 */

typedef struct I2C_Regs {    // I2C interface structure
	char status; 
    char status_in;
	char cmd;           //commands from motherboard
    char data_length;
	char acs_outputs;   //data to motherboard
    char acs_inputs;    //data from motherboard
	char buffer[BUFFER_LENGTH];
    char osdp_tx_buffer[BUFFER_LENGTH];
    char osdp_data_length;
    char osdp_rx_buffer[BUFFER_LENGTH];
    char sw_version[3];
    char hw_version[3];
}I2C_Regs;

extern I2C_Regs MyI2C_Regs;
char currentAccessType;
char old;
SOFT_UART_STRUCT s;
int TAMPERCR_POLARITY;
int timeout_cnt;
int card_ack;   // added GRI 2/2/15
int card_in_buf;    // added GRI 2/3/15

/* COMMANDS */

#define CMD_BOOTLOAD        1
#define CMD_READ_CARD       2
#define CMD_TRIGGER_RELAY1  3
#define CMD_TRIGGER_RELAY2  4
#define CMD_SEND_F2F        5
#define CMD_SEND_HID        6
#define CMD_SEND_PAC        12
#define CMD_SEND_WEIGAND    26



/* ACS INPUT VALUES */
#define LED_IN_RED      0x1
#define LED_IN_GRN      0x2
#define SOUNDER_IN      0x4
#define TAMPERCR_IN     0x8
#define REED_1_IN       0x10
#define REED_2_IN       0x20
#define PWR_RESET       0x40

/* ACS OUTPUT VALUES */
#define LED_OUT_RED   0x1
#define LED_OUT_GRN   0x2
#define SOUNDER_OUT   0x4
#define TAMPERCR_POL  0x8   //Name changed to indicate polarity setting for CR Tamper in webconfig GRI 1/2015
#define RELAY_1_OUT   0x10
#define RELAY_2_OUT   0x20

/* STATUS VALUES */
#define STAT_CHANGE  1
#define STAT_CARD_IN 2
#define STAT_ACS_IN 4 
#define STAT_OSDP_IN 8


/* INPUT STATUS VALUES */
#define STAT_CHANGE 1
#define STAT_ACS_OUT 2
#define STAT_OSDP_OUT 4
#define STAT_CARD_ACK 8


/* INTERNAL DEFINE */
#define PAC 12
#define HID 26

/*I2C Reg Address 

status_output     0
status_input      1
command           2 
data_length       3
acs_outputs       4
acs_inputs        5
buffer[20]        6
osdp_tx_buffer   26 
osdp_data_length 46
osdp_rx_buffer   47 
sw_version[3]    67
hw_version[3]    70

*/

/* [] END OF FILE */

