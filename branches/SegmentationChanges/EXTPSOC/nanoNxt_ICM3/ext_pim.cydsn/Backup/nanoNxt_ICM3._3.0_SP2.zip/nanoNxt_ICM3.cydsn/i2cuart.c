/* =======================================
 *
 * Copyright YOUR COMPANY, THE YEAR
 * All Rights Reserved
 * UNPUBLISHED, LICENSED SOFTWARE.
 *
 * CONFIDENTIAL AND PROPRIETARY INFORMATION
 * WHICH IS THE PROPERTY OF your company.
 *
 * ========================================
*/

/* [] END OF FILE */

#include <project.h>
#include "system.h"




void SendPAC()
{
    int i,j;
    LED_0_Write(0);
    LED_1_Write(0);
  
    for( i = 0; i < 20; i++)
    {
        for( j= 0; j < 12 ; j++)
         UART_1_PutChar(MyI2C_Regs.buffer[j]);
    }

    LED_0_Write(1);
    LED_1_Write(1);
}

int ReadPAC()
{
    int byteCount =0;
    char tmp;
    char ret = 0;
   

    if(UART_1_ReadRxStatus() ==   UART_1_RX_STS_FIFO_NOTEMPTY)
    {
        while(byteCount < 12)
        {
            
            if(UART_1_ReadRxStatus() ==   UART_1_RX_STS_FIFO_NOTEMPTY)
            {
                tmp = UART_1_GetChar();
                if(tmp == 0x02)
                {
                    MyI2C_Regs.buffer[byteCount] = tmp;
                    byteCount++;
                }
                else if(byteCount > 0)
                {
                  MyI2C_Regs.buffer[byteCount] = tmp;
                  byteCount++;
                }
            }
            
        }
        UART_1_ClearRxBuffer();
        MyI2C_Regs.cmd = 0;
        MyI2C_Regs.status |= STAT_CHANGE | STAT_CARD_IN;
        ret = 1;
   
    }
    
    return ret;
}


void SendOSDP()
{
    int i;
    Pin_OSDP_Write(0x1);
    for(i =0 ; i < MyI2C_Regs.osdp_data_length; i++)
    {
     //  UART_OSDP_PutChar(MyI2C_Regs.osdp_tx_buffer[i]);
    }
     Pin_OSDP_Write(0x0);

}

int ReadOSDP()
{
    int byteCount =0;
    char tmp;
    char ret = 0;

    while(UART_OSDP_GetRxBufferSize()> 0)
    {
        
        tmp = UART_OSDP_GetChar();
        MyI2C_Regs.osdp_rx_buffer[byteCount] = tmp;
        byteCount++;
        ret = 1;
    }
    
    UART_OSDP_ClearRxBuffer();
    MyI2C_Regs.status |= STAT_CHANGE | STAT_OSDP_IN;
    return ret;
}


void SetupUART(char accessType)
{

    
    if(currentAccessType != accessType)
    {
        switch(accessType)
        {
            case PAC:
               OptSelect_Write(0);
                break;
            case HID:
               OptSelect_Write(1);
                break;
                
        }
        currentAccessType = accessType;
    }
    
}
