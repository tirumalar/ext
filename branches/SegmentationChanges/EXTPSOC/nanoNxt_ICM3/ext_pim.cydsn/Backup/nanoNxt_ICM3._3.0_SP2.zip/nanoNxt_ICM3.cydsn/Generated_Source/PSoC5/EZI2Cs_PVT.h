/*******************************************************************************
* File Name: .h
* Version 1.90
*
* Description:
*  This file provides private constants and parameter values for the EZI2C
*  component.
*
* Note:
*
********************************************************************************
* Copyright 2013, Cypress Semiconductor Corporation. All rights reserved.
* You may use this file only in accordance with the license, terms, conditions,
* disclaimers, and limitations in the end user license agreement accompanying
* the software package with which this file was provided.
*******************************************************************************/

#if !defined(CY_EZI2C_PVT_EZI2Cs_H)
#define CY_EZI2C_PVT_EZI2Cs_H

#include "EZI2Cs.h"


/***************************************
*     Vars with External Linkage
***************************************/

extern EZI2Cs_BACKUP_STRUCT  EZI2Cs_backup;

extern volatile uint8 EZI2Cs_curStatus; /* Status byte */
extern volatile uint8 EZI2Cs_curState;  /* Current state of I2C state machine */

/* Pointer to data exposed to I2C Master */
extern volatile uint8 * EZI2Cs_dataPtrS1;

/* Size of buffer1 in bytes */
extern volatile uint16 EZI2Cs_bufSizeS1; 

/* Offset for read and write operations, set at each write sequence */
extern volatile uint8 EZI2Cs_rwOffsetS1;

/* Points to next value to be read or written */
extern volatile uint8 EZI2Cs_rwIndexS1;

/* Offset where data is read only */
extern volatile uint16 EZI2Cs_wrProtectS1;

/* If two slave addresses, creat second set of varaibles  */
#if(EZI2Cs_ADDRESSES == EZI2Cs_TWO_ADDRESSES)

    /* Software address compare 1 */
    extern volatile uint8 EZI2Cs_addrS1;

    /* Software address compare 2 */
    extern volatile uint8 EZI2Cs_addrS2;

    /* Pointer to data exposed to I2C Master */
    extern volatile uint8 * EZI2Cs_dataPtrS2;

    /* Size of buffer2 in bytes */
    extern volatile uint16 EZI2Cs_bufSizeS2; 

    /* Offset for read and write operations, set at each write sequence */
    extern volatile uint8 EZI2Cs_rwOffsetS2;

    /* Points to next value to be read or written */
    extern volatile uint8 EZI2Cs_rwIndexS2;

    /* Offset where data is read only */
    extern volatile uint16 EZI2Cs_wrProtectS2;

#endif  /* (EZI2Cs_ADDRESSES == EZI2Cs_TWO_ADDRESSES) */

#if(EZI2Cs_WAKEUP_ENABLED)
    extern volatile uint8 EZI2Cs_wakeupSource;
#endif /* (EZI2Cs_WAKEUP_ENABLED) */

#endif /* CY_EZI2C_PVT_EZI2Cs_H */


/* [] END OF FILE */
