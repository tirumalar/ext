/*******************************************************************************
* File Name: LEDG_OUT.h  
* Version 2.5
*
* Description:
*  This file containts Control Register function prototypes and register defines
*
* Note:
*
********************************************************************************
* Copyright 2008-2014, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions, 
* disclaimers, and limitations in the end user license agreement accompanying 
* the software package with which this file was provided.
*******************************************************************************/

#if !defined(CY_PINS_LEDG_OUT_H) /* Pins LEDG_OUT_H */
#define CY_PINS_LEDG_OUT_H

#include "cytypes.h"
#include "cyfitter.h"
#include "cypins.h"
#include "LEDG_OUT_aliases.h"

/* Check to see if required defines such as CY_PSOC5A are available */
/* They are defined starting with cy_boot v3.0 */
#if !defined (CY_PSOC5A)
    #error Component cy_pins_v2_5 requires cy_boot v3.0 or later
#endif /* (CY_PSOC5A) */

/* APIs are not generated for P15[7:6] */
#if !(CY_PSOC5A &&\
	 LEDG_OUT__PORT == 15 && ((LEDG_OUT__MASK & 0xC0) != 0))


/***************************************
*        Function Prototypes             
***************************************/    

void    LEDG_OUT_Write(uint8 value) ;
void    LEDG_OUT_SetDriveMode(uint8 mode) ;
uint8   LEDG_OUT_ReadDataReg(void) ;
uint8   LEDG_OUT_Read(void) ;
uint8   LEDG_OUT_ClearInterrupt(void) ;


/***************************************
*           API Constants        
***************************************/

/* Drive Modes */
#define LEDG_OUT_DM_ALG_HIZ         PIN_DM_ALG_HIZ
#define LEDG_OUT_DM_DIG_HIZ         PIN_DM_DIG_HIZ
#define LEDG_OUT_DM_RES_UP          PIN_DM_RES_UP
#define LEDG_OUT_DM_RES_DWN         PIN_DM_RES_DWN
#define LEDG_OUT_DM_OD_LO           PIN_DM_OD_LO
#define LEDG_OUT_DM_OD_HI           PIN_DM_OD_HI
#define LEDG_OUT_DM_STRONG          PIN_DM_STRONG
#define LEDG_OUT_DM_RES_UPDWN       PIN_DM_RES_UPDWN

/* Digital Port Constants */
#define LEDG_OUT_MASK               LEDG_OUT__MASK
#define LEDG_OUT_SHIFT              LEDG_OUT__SHIFT
#define LEDG_OUT_WIDTH              1u


/***************************************
*             Registers        
***************************************/

/* Main Port Registers */
/* Pin State */
#define LEDG_OUT_PS                     (* (reg8 *) LEDG_OUT__PS)
/* Data Register */
#define LEDG_OUT_DR                     (* (reg8 *) LEDG_OUT__DR)
/* Port Number */
#define LEDG_OUT_PRT_NUM                (* (reg8 *) LEDG_OUT__PRT) 
/* Connect to Analog Globals */                                                  
#define LEDG_OUT_AG                     (* (reg8 *) LEDG_OUT__AG)                       
/* Analog MUX bux enable */
#define LEDG_OUT_AMUX                   (* (reg8 *) LEDG_OUT__AMUX) 
/* Bidirectional Enable */                                                        
#define LEDG_OUT_BIE                    (* (reg8 *) LEDG_OUT__BIE)
/* Bit-mask for Aliased Register Access */
#define LEDG_OUT_BIT_MASK               (* (reg8 *) LEDG_OUT__BIT_MASK)
/* Bypass Enable */
#define LEDG_OUT_BYP                    (* (reg8 *) LEDG_OUT__BYP)
/* Port wide control signals */                                                   
#define LEDG_OUT_CTL                    (* (reg8 *) LEDG_OUT__CTL)
/* Drive Modes */
#define LEDG_OUT_DM0                    (* (reg8 *) LEDG_OUT__DM0) 
#define LEDG_OUT_DM1                    (* (reg8 *) LEDG_OUT__DM1)
#define LEDG_OUT_DM2                    (* (reg8 *) LEDG_OUT__DM2) 
/* Input Buffer Disable Override */
#define LEDG_OUT_INP_DIS                (* (reg8 *) LEDG_OUT__INP_DIS)
/* LCD Common or Segment Drive */
#define LEDG_OUT_LCD_COM_SEG            (* (reg8 *) LEDG_OUT__LCD_COM_SEG)
/* Enable Segment LCD */
#define LEDG_OUT_LCD_EN                 (* (reg8 *) LEDG_OUT__LCD_EN)
/* Slew Rate Control */
#define LEDG_OUT_SLW                    (* (reg8 *) LEDG_OUT__SLW)

/* DSI Port Registers */
/* Global DSI Select Register */
#define LEDG_OUT_PRTDSI__CAPS_SEL       (* (reg8 *) LEDG_OUT__PRTDSI__CAPS_SEL) 
/* Double Sync Enable */
#define LEDG_OUT_PRTDSI__DBL_SYNC_IN    (* (reg8 *) LEDG_OUT__PRTDSI__DBL_SYNC_IN) 
/* Output Enable Select Drive Strength */
#define LEDG_OUT_PRTDSI__OE_SEL0        (* (reg8 *) LEDG_OUT__PRTDSI__OE_SEL0) 
#define LEDG_OUT_PRTDSI__OE_SEL1        (* (reg8 *) LEDG_OUT__PRTDSI__OE_SEL1) 
/* Port Pin Output Select Registers */
#define LEDG_OUT_PRTDSI__OUT_SEL0       (* (reg8 *) LEDG_OUT__PRTDSI__OUT_SEL0) 
#define LEDG_OUT_PRTDSI__OUT_SEL1       (* (reg8 *) LEDG_OUT__PRTDSI__OUT_SEL1) 
/* Sync Output Enable Registers */
#define LEDG_OUT_PRTDSI__SYNC_OUT       (* (reg8 *) LEDG_OUT__PRTDSI__SYNC_OUT) 


#if defined(LEDG_OUT__INTSTAT)  /* Interrupt Registers */

    #define LEDG_OUT_INTSTAT                (* (reg8 *) LEDG_OUT__INTSTAT)
    #define LEDG_OUT_SNAP                   (* (reg8 *) LEDG_OUT__SNAP)

#endif /* Interrupt Registers */

#endif /* CY_PSOC5A... */

#endif /*  CY_PINS_LEDG_OUT_H */


/* [] END OF FILE */
