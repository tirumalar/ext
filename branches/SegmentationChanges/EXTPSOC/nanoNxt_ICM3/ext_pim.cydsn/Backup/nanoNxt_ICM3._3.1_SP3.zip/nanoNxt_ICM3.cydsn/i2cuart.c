/* =======================================
 *
 * Copyright YOUR COMPANY, THE YEAR
 * All Rights Reserved
 * UNPUBLISHED, LICENSED SOFTWARE.
 *
 * CONFIDENTIAL AND PROPRIETARY INFORMATION
 * WHICH IS THE PROPERTY OF your company.
 *
 * ========================================
*/

/* [] END OF FILE */

#include <project.h>
#include "system.h"
#include "LED_0.h"
#include "LED_1.h"
#include "LED_2.h"
#include "i2cuart.h"



void SendPAC()
{
    int i,j;
    LED_GRN_Write(0);
    LED_YEL_Write(0);
  
    for( i = 0; i < 20; i++)
    {
        for( j= 0; j < 12 ; j++)
         UART_1_PutChar(MyI2C_Regs.buffer[j]);
    }

    LED_GRN_Write(1);
    LED_YEL_Write(1);
}

int ReadPAC()
{
    int byteCount =0;
    char tmp;
    char ret = 0;
   

    if(UART_1_ReadRxStatus() ==   UART_1_RX_STS_FIFO_NOTEMPTY)
    {
        while(byteCount < 12)
        {
            
            if(UART_1_ReadRxStatus() ==   UART_1_RX_STS_FIFO_NOTEMPTY)
            {
                tmp = UART_1_GetChar();
                if(tmp == 0x02)
                {
                    MyI2C_Regs.buffer[byteCount] = tmp;
                    byteCount++;
                }
                else if(byteCount > 0)
                {
                  MyI2C_Regs.buffer[byteCount] = tmp;
                  byteCount++;
                }
            }
            
        }
        UART_1_ClearRxBuffer();
        MyI2C_Regs.cmd = 0;
        card_in_buf = 1;
        MyI2C_Regs.status |= STAT_CHANGE | STAT_CARD_IN;
        ret = 1;
   
    }
    
    return ret;
}

void SetupUART(char accessType)
{

    
    if(currentAccessType != accessType)
    {
        switch(accessType)
        {
            case PAC:
               OptSelect_Write(0);
                break;
            case HID:
               OptSelect_Write(1);
                break;
                
        }
        currentAccessType = accessType;
    }
    
}

void ClearOsdpBuffer()
{
    int i;
        UART_OSDP_ClearRxBuffer();
        for ( i=0; i<OSDP_BUFFER_LENGTH; i++){
            MyI2C_Regs.osdp_buffer[i]=0;
        }
        MyI2C_Regs.osdp_data_length = 0;
}

void SendOSDP()
{
    
    Mode_Sel_ACS_Write(1); //set io chip to 485
    TX_EN_Write(1);
    UART_OSDP_LoadTxConfig();
    CyDelay(1); //Driver Output Enable Time, do not reduce. 
    UART_OSDP_PutArray(MyI2C_Regs.osdp_buffer,MyI2C_Regs.osdp_data_length); 
    CyDelay(5); //minmum 4m

    MyI2C_Regs.osdp_status |= OSDP_DATA_SENT;
    UART_OSDP_LoadRxConfig();
    ClearOsdpBuffer();
    TX_EN_Write(0);

}

struct OSDP_MSG_HEADER {
    unsigned char addr;
    union{
        short len;
        unsigned char length[2];
    }u;
} osdp_msg_header,osdp_reader_msg_header;

void ReadOSDP()
{
    int byteCount =0;
    unsigned char tmp = 0;
    char msg_started = 0;
    int i;
    
    Mode_Sel_ACS_Write(1); //set the chip to RS485 mode
    if (UART_OSDP_GetRxBufferSize()>= 7)
    {
        for(i=0;i<7;i++) {
            tmp = UART_OSDP_GetChar();
            if (tmp == 0x53) {
                msg_started = 1;
                break;
            }
        } 
        
        if (msg_started){
            tmp = UART_OSDP_GetChar();
            osdp_msg_header.addr = tmp;
            
            tmp = UART_OSDP_GetChar();
            osdp_msg_header.u.length[0] = tmp;
            
            tmp = UART_OSDP_GetChar();
            osdp_msg_header.u.length[1] = tmp;
        } 
        else
        {
            //the message is not started yet
            return;
        }
        
        if (osdp_msg_header.u.len <7) return; //discard bad message, too short.
        
        ClearOsdpBuffer();
        
        byteCount = 0;
        MyI2C_Regs.osdp_buffer[byteCount] = 0x53;
        byteCount++;
        MyI2C_Regs.osdp_buffer[byteCount] = osdp_msg_header.addr;
        byteCount++;
        MyI2C_Regs.osdp_buffer[byteCount] = osdp_msg_header.u.length[0];
        byteCount++;
        MyI2C_Regs.osdp_buffer[byteCount] = osdp_msg_header.u.length[1];
        byteCount++;
        
        if(osdp_msg_header.u.len > OSDP_BUFFER_LENGTH){
            //error, the message is too long
            osdp_msg_header.u.len = OSDP_BUFFER_LENGTH;
            return;
        }
        
        for (; byteCount<osdp_msg_header.u.len;){  //may need timeout here
            if (UART_OSDP_GetRxBufferSize()>0){
                tmp = UART_OSDP_GetChar();
                MyI2C_Regs.osdp_buffer[byteCount] = tmp;
                byteCount++;
            }
        }

        MyI2C_Regs.osdp_data_length = osdp_msg_header.u.len;
        MyI2C_Regs.osdp_status |= OSDP_DATA_IN_READY;
    }
}

void SetOSDPRate(){
    char rate;
    
    UART_OSDP_Enable();

    rate = MyI2C_Regs.osdp_rate;
    switch(rate){
        case OSDP_9600:
            Clock_5_SetDividerValue(625); //  48000000/625=9600
            break;
        case OSDP_19200:
            Clock_5_SetDividerValue(312);
            break;
        case OSDP_38400:
            Clock_5_SetDividerValue(156);
            break;
        case OSDP_115200:
            Clock_5_SetDividerValue(52);
            break;
        default:;    
    }
    
}

////////////////OSDP READER//////////////////

char keepALive[OSDP_READER_BUFFER_LENGTH];
unsigned char keepALiveLength;

//#define SEND_OSDP_READER 1
//#define OSDP_READER_SENT 0
char sendOSDPReaderSet;
unsigned char OSDPReaderTask;

uint8 InterruptCnt;

CY_ISR(KeepAliveInterruptHandler)
{
	/* Read Status register in order to clear the sticky Terminal Count (TC) bit 
	 * in the status register.
	 */
   	OSDPReaderTimer_STATUS;
    
	/* alternate LEDs for debugging 
     * when interrupts received
    if( InterruptCnt++ % 2 == 0){
        LED_GRN_Write(1u);    
        LED_YEL_Write(0u);    
    }else{
        LED_GRN_Write(0u);    
        LED_YEL_Write(1u);    
    }
     */
    OSDPReaderTask |= (0x1 << OSDP_SEND_READER);  //send the keep alive to the card reader
 
}



void ClearOsdpReaderBuffer()
{
    int i;
        UART_OSDP_READER_ClearRxBuffer();
        for ( i=0; i<OSDP_READER_BUFFER_LENGTH; i++){
            MyI2C_Regs.osdp_reader_buffer[i]=0;
        }
        MyI2C_Regs.osdp_reader_data_length = 0;
}

void SendOSDPReader()
{
    
    Mode_Sel_CR_Write(1); //set the SP335e chip to RS485
    CR_DE_Write(1);
    UART_OSDP_READER_LoadTxConfig();
    CyDelay(1); //Driver Output Enable Time, do not reduce. 
    UART_OSDP_READER_PutArray(MyI2C_Regs.osdp_reader_buffer,MyI2C_Regs.osdp_reader_data_length); 
    CyDelay(5); //minmum 4ms

    MyI2C_Regs.osdp_status |= OSDP_READER_DATA_SENT;
    UART_OSDP_READER_LoadRxConfig();
    CR_DE_Write(0);

}

void ReadOSDPReader()
{
    int byteCount =0;
    unsigned char tmp = 0;
    char msg_started = 0;
    int i;
    
    Mode_Sel_CR_Write(1); //set the chip to RS485 mode
    if (UART_OSDP_READER_GetRxBufferSize()>= 7)
    {
        for(i=0;i<7;i++) {
            tmp = UART_OSDP_READER_GetChar();
            if (tmp == 0x53) {
                msg_started = 1;
                break;
            }
        } 
        
        if (msg_started){
            tmp = UART_OSDP_READER_GetChar();
            osdp_reader_msg_header.addr = tmp;
            
            tmp = UART_OSDP_READER_GetChar();
            osdp_reader_msg_header.u.length[0] = tmp;
            
            tmp = UART_OSDP_READER_GetChar();
            osdp_reader_msg_header.u.length[1] = tmp;
        } 
        else
        {
            //the message is not started yet
            return;
        }
        
        if (osdp_reader_msg_header.u.len <7) return; //discard bad message, too short.
        
        ClearOsdpReaderBuffer();
        byteCount = 0;
        MyI2C_Regs.osdp_reader_buffer[byteCount] = 0x53;
        byteCount++;
        MyI2C_Regs.osdp_reader_buffer[byteCount] = osdp_reader_msg_header.addr;
        byteCount++;
        MyI2C_Regs.osdp_reader_buffer[byteCount] = osdp_reader_msg_header.u.length[0];
        byteCount++;
        MyI2C_Regs.osdp_reader_buffer[byteCount] = osdp_reader_msg_header.u.length[1];
        byteCount++;
        
        if(osdp_reader_msg_header.u.len > OSDP_READER_BUFFER_LENGTH){
            //error, the message is too long
            osdp_reader_msg_header.u.len = OSDP_READER_BUFFER_LENGTH;
            return;
        }
        
        for (; byteCount<osdp_reader_msg_header.u.len;){  //may need timeout here
            if (UART_OSDP_READER_GetRxBufferSize()>0){
                tmp = UART_OSDP_READER_GetChar();
                MyI2C_Regs.osdp_reader_buffer[byteCount] = tmp;
                byteCount++;
            }
        }

        MyI2C_Regs.osdp_reader_data_length = osdp_reader_msg_header.u.len;
        MyI2C_Regs.osdp_status |= OSDP_READER_DATA_IN_READY;
    }
}

void SetOSDPReaderSpeed(){
    char rate;
    
    UART_OSDP_READER_Enable();

    rate = MyI2C_Regs.osdp_reader_rate;
    switch(rate){
        case OSDP_9600:
            Clock_6_SetDividerValue(625); //  48000000/625=9600
            break;
        case OSDP_19200:
            Clock_6_SetDividerValue(312);
            break;
        case OSDP_38400:
            Clock_6_SetDividerValue(156);
            break;
        case OSDP_115200:
            Clock_6_SetDividerValue(52);
            break;
        default:;    
    }
    
}


void SetOSDPKeepALive(char *message, unsigned char msg_size){
    int i;
    if (msg_size <= OSDP_READER_BUFFER_LENGTH){
        for ( i=0; i<msg_size; i++){
            keepALive[i]=message[i];
        }
    }
    keepALiveLength = msg_size;
}

void SendOSDPReaderKeepALive(){
    int i;
    for(i=0; i<OSDP_READER_BUFFER_LENGTH; i++){
        MyI2C_Regs.osdp_reader_buffer[i] = keepALive[i];
    }
    MyI2C_Regs.osdp_reader_data_length = keepALiveLength;
    SendOSDPReader();
}

