/*******************************************************************************
* File Name: EZI2CPin.c  
* Version 2.10
*
* Description:
*  This file contains API to enable firmware control of a Pins component.
*
* Note:
*
********************************************************************************
* Copyright 2008-2014, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions, 
* disclaimers, and limitations in the end user license agreement accompanying 
* the software package with which this file was provided.
*******************************************************************************/

#include "cytypes.h"
#include "EZI2CPin.h"

/* APIs are not generated for P15[7:6] on PSoC 5 */
#if !(CY_PSOC5A &&\
	 EZI2CPin__PORT == 15 && ((EZI2CPin__MASK & 0xC0) != 0))


/*******************************************************************************
* Function Name: EZI2CPin_Write
********************************************************************************
*
* Summary:
*  Assign a new value to the digital port's data output register.  
*
* Parameters:  
*  prtValue:  The value to be assigned to the Digital Port. 
*
* Return: 
*  None
*  
*******************************************************************************/
void EZI2CPin_Write(uint8 value) 
{
    uint8 staticBits = (EZI2CPin_DR & (uint8)(~EZI2CPin_MASK));
    EZI2CPin_DR = staticBits | ((uint8)(value << EZI2CPin_SHIFT) & EZI2CPin_MASK);
}


/*******************************************************************************
* Function Name: EZI2CPin_SetDriveMode
********************************************************************************
*
* Summary:
*  Change the drive mode on the pins of the port.
* 
* Parameters:  
*  mode:  Change the pins to one of the following drive modes.
*
*  EZI2CPin_DM_STRONG     Strong Drive 
*  EZI2CPin_DM_OD_HI      Open Drain, Drives High 
*  EZI2CPin_DM_OD_LO      Open Drain, Drives Low 
*  EZI2CPin_DM_RES_UP     Resistive Pull Up 
*  EZI2CPin_DM_RES_DWN    Resistive Pull Down 
*  EZI2CPin_DM_RES_UPDWN  Resistive Pull Up/Down 
*  EZI2CPin_DM_DIG_HIZ    High Impedance Digital 
*  EZI2CPin_DM_ALG_HIZ    High Impedance Analog 
*
* Return: 
*  None
*
*******************************************************************************/
void EZI2CPin_SetDriveMode(uint8 mode) 
{
	CyPins_SetPinDriveMode(EZI2CPin_0, mode);
	CyPins_SetPinDriveMode(EZI2CPin_1, mode);
}


/*******************************************************************************
* Function Name: EZI2CPin_Read
********************************************************************************
*
* Summary:
*  Read the current value on the pins of the Digital Port in right justified 
*  form.
*
* Parameters:  
*  None
*
* Return: 
*  Returns the current value of the Digital Port as a right justified number
*  
* Note:
*  Macro EZI2CPin_ReadPS calls this function. 
*  
*******************************************************************************/
uint8 EZI2CPin_Read(void) 
{
    return (EZI2CPin_PS & EZI2CPin_MASK) >> EZI2CPin_SHIFT;
}


/*******************************************************************************
* Function Name: EZI2CPin_ReadDataReg
********************************************************************************
*
* Summary:
*  Read the current value assigned to a Digital Port's data output register
*
* Parameters:  
*  None 
*
* Return: 
*  Returns the current value assigned to the Digital Port's data output register
*  
*******************************************************************************/
uint8 EZI2CPin_ReadDataReg(void) 
{
    return (EZI2CPin_DR & EZI2CPin_MASK) >> EZI2CPin_SHIFT;
}


/* If Interrupts Are Enabled for this Pins component */ 
#if defined(EZI2CPin_INTSTAT) 

    /*******************************************************************************
    * Function Name: EZI2CPin_ClearInterrupt
    ********************************************************************************
    * Summary:
    *  Clears any active interrupts attached to port and returns the value of the 
    *  interrupt status register.
    *
    * Parameters:  
    *  None 
    *
    * Return: 
    *  Returns the value of the interrupt status register
    *  
    *******************************************************************************/
    uint8 EZI2CPin_ClearInterrupt(void) 
    {
        return (EZI2CPin_INTSTAT & EZI2CPin_MASK) >> EZI2CPin_SHIFT;
    }

#endif /* If Interrupts Are Enabled for this Pins component */ 

#endif /* CY_PSOC5A... */

    
/* [] END OF FILE */
