/* ========================================
 *
 * Copyright YOUR COMPANY, THE YEAR
 * All Rights Reserved
 * UNPUBLISHED, LICENSED SOFTWARE.
 *
 * CONFIDENTIAL AND PROPRIETARY INFORMATION
 * WHICH IS THE PROPERTY OF your company.
 *
 * ========================================
*/

// GRI 2-2-15: Modified ReadWiegand.

#include <project.h>
#include "system.h"
#include "wiegand.h"
#include "Pulse_50us.h"

CY_ISR(Pin_50us_Reset)
{
    OptSelect_Write(2);
	PS_D1_Write(0);
    isr_50us_GetState();
    Pulse_50us_ReadStatusRegister();
    Pulse_50us_RestoreConfig();
    Pulse_50us_Init();
}
void send_D0_50us_pulse()
{
    OptSelect_Write(3); 
    Pulse_50us_Enable();
}
void send_D1_50us_pulse()
{
    PS_D1_Write(1);
    Pulse_50us_Enable();
}

void SendWeigand(unsigned char *bufp, int nBits)  //Function to send Wiegand Data
{
	int x,y;
	char  d1;
    char count = 0;
    
	/*                        Wiegand protocol
	    A pulse width of 50us to define data
	    A wait period of 2ms after transmitting the above defined pulse
    */
    if (nBits > (WIEGAND_BUFFER_LENGTH << 3)) return; //garbage in
    OptSelect_Write(2); //0, both output high
    PS_D1_Write(0);
    CyDelay(5);
	for (x=0; x< WIEGAND_BUFFER_LENGTH; x++) // Loop over data written from the OMAP
	{
        d1 = bufp[x];
		for (y=0; y <8; y++)  //Transmit each bit at a time
		{	
			count++;
            if (count > nBits)
			{
                OptSelect_Write(2); //0, both output high
                PS_D1_Write(0);
                return;
			}

		    if (d1&0x80) // Check if it a 1 or a 0
			{
                send_D1_50us_pulse();
			}
			else
			{
                send_D0_50us_pulse();
			}			    
			d1=d1<<1;
            CyDelayUs(1030); //1030 = 2ms
		}
	}
}

int ReadWeigand(int nBits, int passmode)
{
    int bitCount;
    int byteCount;
    unsigned char buffer[WIEGAND_BUFFER_LENGTH];  
    int i;
   
    char WD0 = Pin_WD0_Read();
    char WD1 = Pin_WD1_Read();
    card_in_buf = 0;
    if (nBits > (WIEGAND_BUFFER_LENGTH << 3)) return 0; //garbage in
    if( WD0 == 0 || WD1 == 0)
    {
        bitCount=0;
        byteCount=0;
        buffer[byteCount]=0;
        while(byteCount*8+bitCount < nBits)
        {
            if(WD0 == 0)
            {
                Timeout_Timer_Isr_Disable();
                passmode_timeout = 0;
                Timeout_Timer_Isr_Enable();
                while(WD0 != 1)
                {
                    if (passmode_timeout > 80) return(0);  //100
                    WD0 = Pin_WD0_Read();
                }
                bitCount++;
            }
        
            //Read D1 line for input, if yes wait for 50 usec for data to end
            //and write 1 to the bit in the buffer at the right position.            
            else if(WD1 == 0)
            {
                Timeout_Timer_Isr_Disable();
                passmode_timeout = 0;
                Timeout_Timer_Isr_Enable();
                while(WD1 != 1)
                {
                    if (passmode_timeout > 80) return(0);
                    WD1 = Pin_WD1_Read();
                }
                buffer[byteCount] |= (0x01 << (7-bitCount));  //write a 1 to current buffer word 
                bitCount++;
            }
        
            //Reset bitCount
            if (bitCount > 7)
			{
				bitCount = 0;
				byteCount++;
                buffer[byteCount] = 0;
			}
            
            //Read D0 line for input, if yes wait for 50 usec for data to end
            WD0 = Pin_WD0_Read();
            WD1 = Pin_WD1_Read();            
        } //while
        
        MyI2C_Regs.data_length[0] = nBits>>8;
        MyI2C_Regs.data_length[1] = nBits;
        
        if ( passmode)
        {
            SendWeigand(buffer, nBits);
        }
        else
        {
            for (i=0; i<=byteCount; i++)
            {
                MyI2C_Regs.buffer[i] = buffer[i];
                CyDelayUs(1u);  //add some delay for I2C
            }
            card_ack = 0;
            card_in_buf = 1;
            MyI2C_Regs.status_out |= STAT_CHANGE | STAT_CARD_IN ;
            MyI2C_Regs.cmd = CMD_NONE;
            return 1;
        }
    }
    return 0;
}



/* [] END OF FILE */
